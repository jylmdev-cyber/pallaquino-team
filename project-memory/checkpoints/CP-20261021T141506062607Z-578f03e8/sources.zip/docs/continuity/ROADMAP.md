# Evolución propuesta

Priorizar según necesidad real: runners adicionales con contratos explícitos; validadores semánticos por tipo de entregable; adaptadores cloud autenticados; parsers de locks adicionales; sincronización de memoria; firma y restauración segura de respaldos. Cada extensión requiere criterios, pruebas y autorización para efectos externos. No son funcionalidades actuales.

Ver [manual de usuario](../user-manual/MANUAL.md) y [manual técnico](../technical-manual/MANUAL.md).

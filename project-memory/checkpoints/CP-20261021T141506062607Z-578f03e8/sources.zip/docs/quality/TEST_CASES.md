# Casos de prueba

TC-01 init rechaza sobrescritura; TC-02 traversal rechazado; TC-03 dependencia bloquea ejecución; TC-04 cierre exige evidencia; TC-05 lock rechaza segundo escritor; TC-06 contexto conserva tareas; TC-07 red fallida es error; TC-08 copia excluye secretos y verifica SHA; TC-09 cero tests falla; TC-10 cloud API ausente se rechaza; TC-11 contrato de agente inválido falla; TC-12 fuente modificada invalida release. Implementación y casos adicionales en tests/test_core.py.

Ver [manual de usuario](../user-manual/MANUAL.md) y [manual técnico](../technical-manual/MANUAL.md).

"""UDP: analizar, generar, validar y preparar documentación sin publicarla."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from uasek.documentation import main

if __name__=='__main__':
    raise SystemExit(main())

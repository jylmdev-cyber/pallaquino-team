# Decisiones

- Núcleo sin dependencias externas de ejecución.
- Transferencia manual para proveedores cloud; solo Ollama tiene adaptador HTTP nativo.
- Contratos de agentes persistentes; ejecución y revisión por asistente/persona autorizada.
- Plantillas sectoriales son documentación adaptable, no aplicaciones completas.

# Siguientes pasos

- Ejecutar doctor y pruebas en el equipo receptor.
- Seleccionar proyecto e iniciar descubrimiento.
- Ampliar integraciones solo con criterios y pruebas específicas.

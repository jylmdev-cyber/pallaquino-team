# Estado del producto

Núcleo local implementado; contratos, skills y referencias distribuidos. API cloud, ejecución autónoma de modelos, despliegue y generación de sistemas comerciales no forman parte de las capacidades implementadas. La evidencia final y plataformas comprobadas están en quality/VALIDATION_REPORT.md. Estado estructurado propio en project-memory/state.json.

Ver [manual de usuario](../user-manual/MANUAL.md) y [manual técnico](../technical-manual/MANUAL.md).

# Historial de versiones

1.0.0 — 2026-10-21: primera entrega del CLI, memoria schema 1, tareas dependientes, contratos/skills, transferencias manuales, adaptador Ollama local, inventario y seguridad parcial, pruebas y empaquetado. No hay versiones anteriores migradas.

Ver [manual de usuario](../user-manual/MANUAL.md) y [manual técnico](../technical-manual/MANUAL.md).
